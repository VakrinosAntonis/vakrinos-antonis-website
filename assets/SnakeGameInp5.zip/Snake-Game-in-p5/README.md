# Snake-Game-in-p5
Using JavaScript with the p5.js library, i am creating a version of the legendary snake game
